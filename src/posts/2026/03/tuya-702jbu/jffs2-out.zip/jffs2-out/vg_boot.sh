#2016-7-2 new vg_boot.sh 

mdev -s
#cat /proc/modules

rootfs_date=`ls /|grep 00_2`
mtd_date=`ls /mnt/mtd|grep 00_2`
echo =========================================================================
#echo "  Video Front End: $video_frontend"
#echo "  Chip Version: $chipver"
echo "  RootFS Version: $rootfs_date"
echo "  MTD Version: $mtd_date"
echo =========================================================================

#mkdir -p /var/spool/cron/crontabs
#crond
mkdir -p /var/tmp/
mkdir -p /var/avApp/
cp -rp /etc/* /var/tmp/
busybox mount -t tmpfs -o mode=0755 tmpfs /etc
cp -rp /var/tmp/* /etc/


mkdir -p /tmp/msnap
mkdir -p /var/upload/
mkdir -p /var/etc/
mkdir -p /var/net/
insmod /mnt/mtd/module/tx-isp-t21.ko
insmod /mnt/mtd/module/audio.ko sign_mode=1
cp -rp /mnt/mtd/etc/ipcversion /var/etc/

if [ ! -f /var/syscfg/sinfo.conf ];then
insmod /mnt/mtd/module/sinfo.ko
fi

while [ ! -f /var/syscfg/sinfo.conf ]
do
echo 1 > /proc/jz/sinfo/info
sleep 1

grep "sensor:" /proc/jz/sinfo/info > /dev/null
if [ $? -eq 0 ];then
cp /proc/jz/sinfo/info /var/syscfg/sinfo.conf
else
echo "can't get sensor info"
fi
done

#insmod /mnt/mtd/module/sensor_os02b10_t21.ko

/sbin/insmod /lib/modules/mtprealloc.ko
/sbin/insmod /lib/modules/mt7601Usta.ko

ip link set dev wlan0  name ra0
insmod  /mnt/mtd/module/peripher_drv.ko
insmod  /mnt/mtd/module/reset_drv.ko
insmod  /mnt/mtd/module/NetLED_drv.ko
#insmod /mnt/mtd/module/zoom_drv.ko
#wpa_supplicant -Dnl80211 -Dwext -ira0 -c/var/syscfg/wpa_supplicant.conf -B

ifconfig lo 127.0.0.1
ifconfig eth0 0.0.0.0  
ifconfig ra0 0.0.0.0
export LD_LIBRARY_PATH=/mnt/mtd/lib:/lib
export PATH=/gm/bin:/bin:/sbin:/usr/bin:/usr/sbin:$PATH

insmod /lib/modules/mmc_core.ko
insmod /lib/modules/mmc_block.ko
insmod /lib/modules/jzmmc_v12.ko
mount /dev/mmcblk0p1 /mnt/mmc

sh /run_cmd.sh > /dev/null 2>&1&

/mnt/mtd/app/tuya &
